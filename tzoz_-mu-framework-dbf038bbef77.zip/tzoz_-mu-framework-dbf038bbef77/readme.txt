TITLE:

mu-framework

AUTHOR:

tzoz_ (aka ph0ne)

DESCRIPTION:

"mu" is a small memory hacking framework primarily intended for use with,
but not limited to, Valve Corporation's Source(tm) game engine.

this framework does not make use of the Microsoft Visual C-Runtime library,
or any external library for that matter. only the necessary headers
are included for the purpose of emulating dependencies related to
MSVCRT, KERNEL32, NTDLL, etc.

with that established, the framework is geared towards use on
Microsoft NT operating system platforms (primarily Windows 7)

CREDITS (in no particular order):

Badster
wav
s0beit
praydog
Ecksy
AkaneTendo
Casual_Hacker
Tamimego
Darawk
Tabris
Tetsuo
Valve Corporation
Id Software